
/**
  * Created by Rajarshi on 03/10/16.
  */

/**
  * Created by Rajarshi on 03/10/16.
  */

object KafkaSender__1 {
  def main(args: Array[String]): Unit = {
    val bufferedSource = scala.io.Source.fromFile("//DIN16000602/ClickStreamData/rajsarka/clickStream_data_Generator/generated_dataset/Date-2016-09-28.csv")
    for (line <- bufferedSource.getLines()){
//      val Array(f1, f2, f3, f4, f5 ,f6, f7, f8) = line.split(",").map(_.trim)
//      val message = f1 + f2 + f3 + f4 + f5 + f6 + f7 + f8
      println(line)

    }
  }

}
