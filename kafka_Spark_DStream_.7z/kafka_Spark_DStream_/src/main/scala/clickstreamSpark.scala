import org.apache.spark.streaming.{Milliseconds, Seconds, StreamingContext}
import Utilities._
import kafka.serializer.StringDecoder
import org.apache.kafka.clients.producer.{KafkaProducer, ProducerConfig, ProducerRecord}
import org.apache.spark.SparkContext
//import org.apache.spark.sql.SparkSession
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.kafka.KafkaUtils
import java.util.concurrent._
import java.util.concurrent.atomic._


/**
  * Created by soumyaka on 10/6/2016.
  */
object clickstreamSpark {
  def main(args: Array[String]): Unit = {
//    var numberOfRows = new AtomicLong(0)
//    var numberOfBounces = new AtomicLong(0)

    val ssc = new StreamingContext("local[*]", "KafkaExample", Seconds(1))
    /*val spark = SparkSession.builder().getOrCreate()
    import spark.implicits._*/
    setupLogging()

    val kafkaParams = Map("metadata.broker.list" -> "DIN16000309:9092")

    val topics = List("test-input").toSet

    val kafkaOutputBrokers = "DIN16000309:9092"
    val kafkaOutputTopic = "test-output1"

    val lines = KafkaUtils.createDirectStream[String, String, StringDecoder, StringDecoder](
      ssc, kafkaParams, topics)

    val customDstream = lines.map(line => {
      val landingPage = line._2.split(",")(6)
      val time = line._2.split(",")(7).toDouble
      val user = line._2.split(",")(3)
      (landingPage, time, user)
    })

    averageTimePerPage(customDstream, kafkaOutputTopic = "avgTimePerPage", kafkaOutputBrokers)
    bounceRate(customDstream, kafkaOutputTopic = "bounceRate", kafkaOutputBrokers)


    /*averageTimePerPage.foreachRDD(rdd => {        //code to create each rdd into DF and then into tempTable
      val df = rdd.toDF("line", "averageTime")      //This can be used with JDBC server to query
      df.createOrReplaceTempView("avgTimePerLine")
    })*/

    //Start the application
    ssc.checkpoint("C:/checkpoint/")
    ssc.start()
    ssc.awaitTermination()
  }

  def averageTimePerPage(customDstream: DStream[(String, Double, String)],
                         kafkaOutputTopic: String, kafkaOutputBrokers: String): Unit = {


    val averageTimePerPage = customDstream.map(line => (line._1, (line._2, 1)))
      .reduceByKeyAndWindow((tup1, tup2) => (tup1._1 + tup2._1, tup1._2 + tup2._2),
        (tup1, tup2) => (tup1._1 - tup2._1, tup1._2 - tup2._2),
        windowDuration = Seconds(20),
        slideDuration = Seconds(2))
      .map(line => (line._1, line._2._1/line._2._2))


    averageTimePerPage.foreachRDD(rdd => {
      rdd.foreachPartition(partition => {

        val producer = new KafkaProducer[String, String](setupKafkaProducer(kafkaOutputBrokers))
        partition.foreach(record => {
          val data = record.toString
          val message = new ProducerRecord[String, String](kafkaOutputTopic, data)
          producer.send(message)

        })
        producer.close()
      })
    })
  }

  def bounceRate(customDstream: DStream[(String, Double, String)],
                         kafkaOutputTopic: String, kafkaOutputBrokers: String): Unit = {


    val numberOfBounces = customDstream.map(line => {if(line._2 < 2) (1,1) else (1,0)})
      .reduceByWindow((tup1, tup2) => (tup1._1 + tup2._1, tup1._2 + tup2._2),
        (tup1, tup2) => (tup1._1 - tup2._1, tup1._2 - tup2._2 ), windowDuration = Seconds(20), slideDuration = Seconds(2))
        .map(line => line._2.toDouble / line._1.toDouble)


    numberOfBounces.foreachRDD(rdd => {
      rdd.foreachPartition(partition => {

        val producer = new KafkaProducer[String, String](setupKafkaProducer(kafkaOutputBrokers))
        partition.foreach(record => {
          val data = record.toString
          val message = new ProducerRecord[String, String](kafkaOutputTopic, data)
          producer.send(message)

        })
        producer.close()
      })
    })
  }

}
