import org.apache.spark.{SparkConf, SparkContext}
import com.datastax.spark.connector._
import org.apache.spark.sql._
/**
 * Created by rajsarka on 10/17/2016.
 */
object readFromCassandra {
  def main(args: Array[String]): Unit = {
    val confStandalone = new SparkConf(true)
      .set("spark.cassandra.connection.host","127.0.0.1")
      .setMaster("local[*]")
      .set("spark.cassandra.connection.native.port", "9042")
      .set("spark.cassandra.connection.rpc.port", "9160")
      .setAppName("rajsarka-test")
      //.set("spark.eventLog.enabled", "true")

    val sc1 = new SparkContext( confStandalone )
    val table_temp = sc1.cassandraTable[(Int, String, String, Boolean)]("rajsarka", "emp")
    table_temp.collect().foreach(println)

  }

//  case class employee (empid: Int, l_name: String, f_name: String, is_hair: Boolean)

}
